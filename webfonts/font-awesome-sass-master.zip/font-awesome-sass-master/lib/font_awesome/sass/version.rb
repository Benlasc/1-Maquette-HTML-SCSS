module FontAwesome
  module Sass
    VERSION = '5.15.1'.freeze
  end
end
